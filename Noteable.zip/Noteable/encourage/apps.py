from django.apps import AppConfig


class EncourageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'encourage'
